# GDHCNParticipantDID-XXD-DEV-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXD-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXD-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXD Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXD:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXD/DSC/did.json

**managingOrganization**: [Organization DEV Participant XXD](Organization-GDHCNParticipant-XXD-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXD:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXD-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXD Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXD:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXD/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXD-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXD:DSC"
}

```
