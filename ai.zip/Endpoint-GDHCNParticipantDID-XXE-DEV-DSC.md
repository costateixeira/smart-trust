# GDHCNParticipantDID-XXE-DEV-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-XXE-DEV-DSC**

## Endpoint: GDHCNParticipantDID-XXE-DEV-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: DEV Participant XXE Trustlist (DID v2) - DEV - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:XXE:DSC resolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXE/DSC/did.json

**managingOrganization**: [Organization DEV Participant XXE](Organization-GDHCNParticipant-XXE-DEV.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:XXE:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-XXE-DEV-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "DEV Participant XXE Trustlist (DID v2) - DEV - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:XXE:DSC\nresolvable at https://tng-cdn-dev.who.int/v2/trustlist/-/XXE/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-XXE-DEV"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:XXE:DSC"
}

```
