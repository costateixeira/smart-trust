# GDHCNParticipantDID-LTU-DSC - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-LTU-DSC**

## Endpoint: GDHCNParticipantDID-LTU-DSC

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Lithuania Trustlist (DID v2) - Document Signing Certificates did:web:tng-cdn.who.int:v2:trustlist:-:LTU:DSC resolvable at https://tng-cdn.who.int/v2/trustlist/-/LTU/DSC/did.json

**managingOrganization**: [Organization Lithuania](Organization-GDHCNParticipant-LTU.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:LTU:DSC



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-LTU-DSC",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Lithuania Trustlist (DID v2) - Document Signing Certificates\ndid:web:tng-cdn.who.int:v2:trustlist:-:LTU:DSC\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/LTU/DSC/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-LTU"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:LTU:DSC"
}

```
