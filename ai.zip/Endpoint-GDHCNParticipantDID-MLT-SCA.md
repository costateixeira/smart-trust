# GDHCNParticipantDID-MLT-SCA - WHO SMART Trust v1.6.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **GDHCNParticipantDID-MLT-SCA**

## Endpoint: GDHCNParticipantDID-MLT-SCA

Profile: [mCSD Endpoint](https://profiles.ihe.net/ITI/mCSD/4.0.0/StructureDefinition-IHE.mCSD.Endpoint.html)

**status**: Active

**connectionType**: 

**name**: Malta Trustlist (DID v2) - Certificate Signing Authority did:web:tng-cdn.who.int:v2:trustlist:-:MLT:SCA resolvable at https://tng-cdn.who.int/v2/trustlist/-/MLT/SCA/did.json

**managingOrganization**: [Organization Malta](Organization-GDHCNParticipant-MLT.md)

**address**: did:web:tng-cdn.who.int:v2:trustlist:-:MLT:SCA



## Resource Content

```json
{
  "resourceType" : "Endpoint",
  "id" : "GDHCNParticipantDID-MLT-SCA",
  "meta" : {
    "profile" : ["https://profiles.ihe.net/ITI/mCSD/StructureDefinition/IHE.mCSD.Endpoint"]
  },
  "status" : "active",
  "connectionType" : [null],
  "name" : "Malta Trustlist (DID v2) - Certificate Signing Authority\ndid:web:tng-cdn.who.int:v2:trustlist:-:MLT:SCA\nresolvable at https://tng-cdn.who.int/v2/trustlist/-/MLT/SCA/did.json",
  "managingOrganization" : {
    "reference" : "Organization/GDHCNParticipant-MLT"
  },
  "address" : "did:web:tng-cdn.who.int:v2:trustlist:-:MLT:SCA"
}

```
